use webtest;
CREATE TABLE IF NOT EXISTS `webtest`.`cart` (
  `cartno` INT NOT NULL AUTO_INCREMENT COMMENT '장바구니 번호',
  `count` INT NOT NULL,
  `contentsno` INT NOT NULL,
  `id` VARCHAR(10) NOT NULL,
  `size` VARCHAR(3) NULL,
  PRIMARY KEY (`cartno`),
  CONSTRAINT `fk_cart_contents1`
    FOREIGN KEY (`contentsno`)
    REFERENCES `webtest`.`contents` (`contentsno`)
    ON UPDATE CASCADE
    ON DELETE CASCADE,
  CONSTRAINT `fk_cart_member1`
    FOREIGN KEY (`id`)
    REFERENCES `webtest`.`member` (`id`)
    ON UPDATE CASCADE
    ON DELETE CASCADE
);
select * from cart;
insert into cart(id,contentsno,count) values('test',1,1);

update cart
set size = 'L'
where id = 'test';

delete from cart
where cartno = 8;
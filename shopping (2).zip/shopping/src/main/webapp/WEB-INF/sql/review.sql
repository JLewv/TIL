use webtest;
create table review(
   rnum int not null auto_increment primary key,
   content varchar(500) not null,
   regdate date not null,
   id varchar(10) not null,
   contentsno int(7) not null,
   foreign key (contentsno) references contents(contentsno)
);
select * from information_schema.table_constraints where table_name = 'review';
alter table review add foreign key (id) references member(id);
alter table review drop foreign key review_ibfk_2;

select * from review;

insert into review(content, regdate, id, contentsno)
values('의견입니다.',sysdate(),'user1',34);
 
 
-- list(목록)
select rnum, content, regdate, id, contentsno
from review
where contentsno = 34
order by rnum DESC
limit 0, 3;
 
 
-- total(목록)
select count(*) from review
where contentsno = 1;
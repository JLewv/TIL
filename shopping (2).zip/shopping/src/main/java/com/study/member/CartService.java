package com.study.member;

import java.util.List;

public interface CartService {

	public int addCart(CartDTO dto); //카트추가
	
//	public int deleteCart(int cartno);
//	
//	public int modifyCount(CartDTO dto); //수량 조절
//	
	public List<CartDTO> getCart(String id);
//	
	public CartDTO checkCart(CartDTO dto);

	
// 강사님ver
	int create(CartDTO dto);

	List<CartDTO> list(String id);

	void delete(int cartno);
}

package com.study.member;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("com.study.member.CartServiceImpl")
public class CartServiceImpl implements CartService {

	@Autowired
	private CartMapper mapper;

	@Override
	public List<CartDTO> getCart(String id) {
		// TODO Auto-generated method stub
		return mapper.getCart(id);
	}

	@Override
	public int addCart(CartDTO dto) {
		// TODO Auto-generated method stub
		return mapper.addCart(dto);
	}

	@Override
	public CartDTO checkCart(CartDTO dto) {
		// TODO Auto-generated method stub
		return mapper.checkCart(dto);
	}
//강사님ver
	@Override
	public int create(CartDTO dto) {
		// TODO Auto-generated method stub
		return mapper.create(dto);
	}

	@Override
	public List<CartDTO> list(String id) {
		// TODO Auto-generated method stub
		return mapper.list(id);
	}

	@Override
	public void delete(int cartno) {
		mapper.delete(cartno);
	}
	
}

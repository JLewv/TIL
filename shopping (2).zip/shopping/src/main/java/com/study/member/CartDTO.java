package com.study.member;

import com.study.contents.ContentsDTO;

import lombok.Data;

@Data
public class CartDTO {

	private int cartno;
	private String id;
	private int contentsno;
	private int count;
	private String size;
	//cart
	private String pname;
	private int price;
	private String filename;
	// contents 테이블의 속성, cart테이블과 조인을 해서 장바구니에 뿌려주기 위함
	// 강사님 ver : ContentsDTO dto로 데이터 가져왔음.
	private ContentsDTO cdto;
}

package com.study.member;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class CartController {
	private static final Logger log = LoggerFactory.getLogger(CartController.class);
	  @Autowired
	  @Qualifier("com.study.member.CartServiceImpl")
	  private CartService service;
	  
	  @GetMapping("/cart/delete/{cartno}")
	  public String delete(@PathVariable int cartno) {
		  
		  service.delete(cartno);
		  
		  return "redirect:../list";
	  }
	  
	  @GetMapping("/cart/list") //목록을 Model에 넣기 위해 Model 선언
	  public String list(HttpSession session, Model model) {
		  
		  String id = (String) session.getAttribute("id");
		  model.addAttribute("list", service.list(id));
		  log.info("list:"+service.list(id));
		  return "/cart/list";
	  }
	  
	  @PostMapping("/cart/create")//넘어오는건 json 문자열인데 cartdto로 받겠다.
	  @ResponseBody
	  public String create(@RequestBody CartDTO dto, HttpSession session) {
		  String id = (String)session.getAttribute("id");
		  dto.setId(id);
		  
		  int cnt = service.create(dto);
		  log.info("dto:"+dto);
		  if(cnt==1) return "장바구니에 저장";
		  else return HttpStatus.INTERNAL_SERVER_ERROR.toString();
	  } 
	  
//	  @PostMapping("/cart/addCart")
//	  @ResponseBody
//	  public String addCart(CartDTO dto,HttpServletRequest request) {
//		  HttpSession session = request.getSession();
//		  //MemberDTO mem = (MemberDTO)session.getAttribute("id");
//		  CartDTO cdto = service.checkCart(dto);
//		  
//		  log.info("dto"+dto);
//		  if(cdto != null) {
//			  return "2";
//		  }
////		  log.info("mem"+mem);
////		  if(mem == null) {
////			  return "먼저 로그인을 하세요";
////		  }
//		  int flag = service.addCart(dto);
//		  return flag + "";
//	  }
	  
	  
//	  @GetMapping(value = "/cart/list")//, method = RequestMethod.POST)
//	  public String list(HttpServletRequest request,HttpSession session) {
//		  String id = (String) session.getAttribute("id");
//		  //log.info("id"+id);
//		  
//		  List<CartDTO> list = service.getCart(id);
//		  
//		  request.setAttribute("list", list);
//		  return "/cart/list";
//	  }
}

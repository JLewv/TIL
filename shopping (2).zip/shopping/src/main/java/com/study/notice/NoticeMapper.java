package com.study.notice;

import java.util.List;
import java.util.Map;



public interface NoticeMapper {

	 List<NoticeDTO> list(Map map);
	 
	 int total(Map map);
	 
	 int create(NoticeDTO dto);
	 
	 NoticeDTO read(int noticeno);
	 
	 void upCnt(int noticeno);
	 
	 int delete(int noticeno);
	 
	 int update(NoticeDTO dto);
}

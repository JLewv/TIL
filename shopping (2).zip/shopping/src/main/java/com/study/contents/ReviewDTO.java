package com.study.contents;

import lombok.Data;

@Data
public class ReviewDTO {
	private String rnum;
	private String content;
	private String regdate;
	private String id; 
	private String contentsno;
}

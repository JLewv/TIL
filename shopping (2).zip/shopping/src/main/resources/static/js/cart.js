/*//수량값
let count = $("#quantity").val();
//옵션값 가져오기
$("select[name=size]").change(function(){
	  console.log($(this).val()); //value값 가져오기
	  console.log($("select[name=size] option:selected").text()); //text값 가져오기
	  var size = $("select[name=size] option:selected").text();
	  if($("select[name=size]").disabled){
		size=0;
	}
	  form.size = size
	});
	
// 전송 데이터
let form = {
	id: $("#id").val(),
	contentsno: $("#cno").val(),
	count,
	size
}

function cart() {
	if ( id == '' || id == null ) {
		alert('먼저 로그인을 하세요');
		location.href = '/member/login';
		return;
	} else {
		form.count = count;
		console.log(form.count);
		if(form.size.length > 3){
			alert("사이즈를 선택해주세요");
			return;
		}
		$.ajax({
			url: '/cart/addCart',
			type: 'post',
			data: form,
			success: function(flag) {
				if (flag == '0') {
					alert("장바구니에 추가 실패");
				} else if (flag == '1'){
					alert("장바구니에 추가 되었습니다.");
				} else if (flag == '2'){
					if(confirm("장바구니에 이미 추가되었습니다. 더 추가하시겠습니까?")){
						alert("미구현");
					}
				}

			}
		})
	}
	//카트테이블에 등록하고 등록확인 창 보여주기 (비동기)
}*/

function addCart(param){
	return fetch('/cart/create',{
		method : 'post',
		body : JSON.stringify(param),
		headers: {'Content-Type' : "application/json; charset=utf-8"}
	})
	.then(response => response.text())
	.catch(console.log);
}
